from cms.plugin_base import CMSPluginBase
from cms.plugin_pool import plugin_pool
from coursemanager_cms_integration.models import CourseManagerPluginModel
from django.utils.translation import ugettext as _


class CourseManagerPluginPublisher(CMSPluginBase):
    model = CourseManagerPluginModel  # model where plugin data are saved
    module = _("CourseManager")
    name = _("CourseManager Plugin")  # name of the plugin in the interface
    render_template = "coursemanager_cms_integration/coursemanager_plugin.html"

    def render(self, context, instance, placeholder):
        context.update({'instance': instance})
        return context

plugin_pool.register_plugin(CourseManagerPluginPublisher)  # register the plugin
